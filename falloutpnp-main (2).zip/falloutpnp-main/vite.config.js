export default {
  css: {
    preprocessorOptions: {
      sass: {
        additionalData: `@import "./src/styles/variables.scss";`,
      }
    },
  },
}
