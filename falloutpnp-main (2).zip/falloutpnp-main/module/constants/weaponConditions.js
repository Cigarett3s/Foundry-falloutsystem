export const WEAPON_CONDITIONS = [
  { value: 10, label: 'Fix' },
  { value: 20, label: '-10%' },
  { value: 30, label: '-10%' },
  { value: 40, label: '' },
  { value: 50, label: '' },
  { value: 60, label: '' },
  { value: 70, label: '' },
  { value: 80, label: '' },
  { value: 90, label: '' },
  { value: 100, label: '' },
]
